<?php
function flags()
{
	$flags=[];
	// "4","SSL Sniff","50","2"
	$flags['Key-Is-dUs1mKl4']=4;
	$flags['Key-Is-dUs1mKl4\033[3']=4;
	$flags['dUs1mKl4\033[3']=4;
	// "5","Gaychal","80","3"
	$flags['6523359abf1fc63b2bde16fefbc60bc1']=5;
	// "7","Vigenere 1","100","4"
	$flags['KIWIKI']=7;
	$flags['kiwiki']=7;
	// "8","Vigenere 2","100","4"
	$flags['XEROX']=8;
	$flags['xerox']=8;
	// "9","Vigenere 3","160","4"
	$flags['DAMNLONGPASSWORD']=9;
	$flags[strtolower('DAMNLONGPASSWORD')]=9;

	// "10","Vigenere 4","220","4"
	$flags['THISCIPHERISCALLEDAUTOKEY']=10;
	$flags[strtolower('THISCIPHERISCALLEDAUTOKEY')]=10;
	// "11","Kiwi Forum 1","120","1"
	$flags['8e1bc4281a54da04']=11;
	$flags['8e1be4281a54da04']=11;
	// "19","Kiwi Forum 2","250","1"
	$flags['0390c17ec34f1b4c']=19;
	$flags['90c103c34f7e1b4c']=19;
			 
	// "12","Math Quiz","150","1"
	$flags['second and third']=12;
	$flags['secondandthird']=12;
	// "13","Ugly Bin","180","3"
	$flags['549386633376']=13;
	#possible flags
	#$flags['1648898261152']=13; 

	// "14","SSL Sniff 2","120","2"
	$flags['39u7v25n1jxkl123']=14;
	// "15","Simple Stegano","250","4"
	$flags['tSJ9F4KY04VLXt7mw3mQhu1LBoE']=15;
	// "16","Virtual Virtue","150","3"
	$flags['~~~Ze]z]1']=16; //TODO: possibly more
	$flags['}}}]ezz]1']=16; //TODO: possibly more
	$flags['}}}Ze]z]1']=16; //TODO: possibly more
	$flags['}}}Zezz]1']=16; //TODO: possibly more
	$flags['}}}]e]z]1']=16; //TODO: possibly more
	$flags['}~}]e]z]1']=16; //TODO: possibly more
			
	// "17","Blue Freeze","250","3"
	$flags['Z2iSxXhHSEhH0bhcZ2iSxXhHSEhH0bhc']=17;
	// "18","Leet Maze","250","2"
	$flags['8410393']=18;
	// "20","Captcha Password","300","1"
	$flags['every kiwi is hackable']=20;
	$flags['everykiwiishackable']=20;
	$flags[strtoupper('everykiwiishackable')]=20;
	$flags[strtoupper('every kiwi is hackable')]=20;
	// "21","NTI","150","5"
	$flags['Fpv41tyP9pAcsTODxJT9whBpHe7k']=22;
	// "22","PTI","200","5"
	$flags['IUKtGJFvGuhtXCasgy8FR8kGvNJG']=21;
	// "23","HTI","250","5"
	$flags['RJvmnUmBjhkn8G0Zd0qYHObdKhMB']=23;
	

	$flags['hsABf8jG3VK93hQf']=24; //survey

	return $flags;
}
function salt1($min)
{
	return md5("this is a long constant string which you should not be able to guess".$min);
}
function answer1($min)
{
	return sprintf("%4d",(($min+1)*1379)%10000);
}
function phonelock1($flagmd5)
{
	for ($i=0;$i<25*60;++$i)
	{
		// $t=sprintf("%2d",$i);
		$t=$i;
		if (md5( md5(salt1($t).answer1($t).answer1($t)) )=== $flagmd5 )
			return true;
	}
	return false;
}
function salt2($min)
{
	return md5("this is a long constant string which you should not be able to guess again".$min);
}
function answer2($min,$co=5641)
{
	return str_pad((($min+1)*$co)%10000,4,"0",STR_PAD_LEFT);
	// return str_pad((($min+1)*$co)%10000,4,"0",STR_PAD_LEFT);
}
function phonelock2($flagmd5)
{
	for ($i=0;$i<60;++$i)
	{
		$t=sprintf("%2d",$i);
		if (md5( md5(answer2($t).md5(salt2($t).answer2($t))) )===$flagmd5 )
			return true;
	}
	return false;
}
function match($flagmd5)
{
	$flags=flags();
	foreach ($flags as $key=>$value)
		if (md5($key)===$flagmd5 or md5(strtolower($key))===$flagmd5)
			return $value;
	if (phonelock1($flagmd5))
		return 3; 
	if (phonelock2($flagmd5))
		return 6; 
	return 0;
}

