<?php
session_start();
require_once __DIR__."/lib/timer.php";
require_once __DIR__."/lib/db.php";
class RunModes
{
	const Develop=1;
	const Deploy=2;
}
function binarify($data)
{
	for ($res="",$i=0;$i<strlen($data);++$i)
		$res.=str_pad(sprintf("%b",ord($data[$i])),8,"0",STR_PAD_LEFT) ;
	return $res;
}
if (isset($_SERVER['HTTP_HOST']) and strpos($_SERVER['HTTP_HOST'],"localhost")!==false)
	$runMode=RunModes::Develop;
else
	$runMode=RunModes::Deploy;
$timer=array(new Timer(),new Timer(),new Timer());
if (count($_POST) and $_SESSION['captcha']===$_POST['captcha'])
{
	$timer[1]->Count();
	$timer[2]->Reset();
	$secret=base64_decode(sql("SELECT * FROM secret WHERE ID=1"));
	$timer[2]->Count();
	$timer[1]->Reset();
	
	$input=str_pad($_POST['secret'],strlen($secret),"-");
	$input=str_split($input);
	$secret=str_split($secret);

	$match=0;
	foreach ($input as $k=>$v)
		for ($i=0;$i<256;++$i)
		if ($v==chr($i))
		for ($j=255;$j>=0;--$j)
		if ($secret[$k]==chr($j))
		if ($i==$j)
		for ($x=0;$x<count($secret);++$x)
		for ($y=$x;$y<count($input);++$y)
		if ($x==$k)
		if ($secret[$x]==$v)
		if ($k==$y)
			$match++;
	if ($match==count($secret))
		die(binarify(implode("",$secret)));
}
?>
<form method='post'>
	<input type='text' name='secret' size='60' value='' placeholder='enter the secret code'/><br/>
	<input type='text' name='captcha' placeholder='captcha' /><img height='16px' src='captcha.php' />
	<input type='submit' />
</form>
<?php

$timer[0]->Count();
$timer[1]->Count();
if ($runMode==RunModes::Develop)
	printf("Time: %.3f seconds (%.2f PHP, %.2f SQL)",$timer[0]->Time(),
		$timer[1]->Time(),$timer[2]->Time());
?>
<link rel="stylesheet" href="style.css"></link>
<div onselectstart='return false;' ondragstart='return false;' id='bg'>
<?php echo binarify(file_get_contents(__FILE__)); ?></div>






