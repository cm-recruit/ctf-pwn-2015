<?php
session_start();
require_once __DIR__."/lib/purecaptcha.php";

$captcha=new PureCaptcha();
$_SESSION['captcha']=$captcha->show();