<?php
// require_once __DIR__."/sql.php";
function sql($query)
{
	$pause=(mt_rand(20,50)+(mt_rand(0,100)<10)*mt_rand(1,1000));
	usleep($pause*1000);
	return base64_encode(file_get_contents(__DIR__."/../art.bin"));
}
