<?php
date_default_timezone_set('America/New_York');
function salt($min)
{
	return md5("this is a long constant string which you should not be able to guess again".$min);
}
function answer($min,$co=5641)
{
	return str_pad((($min+1)*$co)%10000,4,"0",STR_PAD_LEFT);
	// return str_pad((($min+1)*$co)%10000,4,"0",STR_PAD_LEFT);
}
/** 
 * returns the number of minutes since the challenge was solved.
 * a good indicator of cheating if larger than a few minutes.
 */
function verify($hash)
{
	for ($i=0;$i<60;++$i)
	{
		$t=sprintf("%2d",$i);
		if (md5(answer($t).md5(salt($t).answer($t)))===$hash)
			return " ".$t;
			// return floor((time()-strtotime(floor($i/60).":".($i%60)))/60) ;
	}
	return false;
}
if (isset($_GET['verify']))
	die(verify($_GET['verify']));
$min=date('i');
$answer=answer($min);
$salt=salt($min);
?>
<html>
<head>
<script src="jquery-1.11.1.min.js"></script>
<script src="jquery-ui.min.js"></script>
<script src="md5.js"></script>
<title>Phone Lock</title>


</head>
<body>
<p>My friend got this other phone which looks and feels almost like my phone. He set a password and 
	is pretty sure he remembers it correctly, but it doesn't work to unlock his phone! 
He asked me to take a look and fix it, but fortunately I have hacker friends who do that.</p>
<p>In the meantime while you fix it, I'll read 
<a href='http://www.forbes.com/sites/timothylee/2011/10/25/yes-google-stole-from-apple-and-thats-a-good-thing/'>this</a>
nice article.</p>
<?php
if (isset($_GET['hint']))
	echo "<p>Oh BTW, my friend told me that it worked at 12:12, 12:25 and 12:38.</p>";?>
<style>
#pad {
	width:350px;
	background-color:#222;
	padding:20px;
	height:300px;
	margin:auto;
	border: 1px solid gray;
	text-align: center;
}
#pad .buttOn, .butt0n {
	width:60px;
	height:30px;
	overflow:hidden;
	text-align: center;
	border:2px outset white;
	color:white;
	margin:2px;
	display:inline-block;
	padding:15px;
	cursor:pointer;
	font-size:24px;
}
#pad .buttOn:HOVER {
}
#pad .buttOn:ACTIVE {
	background-color:gray;
}
#resultHolder {
<?php #$t=str_shuffle($answer); echo "	margin:"; for ($i=0;$i<4;++$i) echo " ".$t[$i]."px"; echo ";\n"?>
	margin:20px auto;
	border:3px inset gray;
	width:250px;
	text-align: center;
	overflow:hidden;
}
#result {
	border:none;
	font-size:60px;
	text-align: center;
	width:250px;
}
.b1 ,:visited{
	background-color:#333;
}
</style>
<div id='resultHolder'>
<input  id='result' readonly='readonly'  value=''></input>
</div>

<div id='pad'>
	<?php
	for ($i=1;$i<=10;++$i)
	{
		if (strpos($answer, ($i%10)."")!==false)
		$t="1"; else $t="l";	
		echo "<a class='button b{$t}'>".($i%10)."</a>	";
	}
	?>
</div>
<script>
result="";
tries=0;
locked=false;
<?php #22 bits takes 1 second, 24 bit takes 4, 28 bits takes 1min, 32 bits takes 16min
#pin combinations are 24 by  default, but if similar chars are found can be down to 12 or even 4 (try on min 12) or 1
#24x16min = 384
#12x16min = 192
#4x16min = 50 min
#C is 10 times faster, resulting in 5 min
?>
salt ="<?php echo substr($salt,0,-6).str_repeat('x',6);?>";
valid="<?php echo substr(md5($salt.$answer),0,-14).str_repeat('x',14);?>"; //md5(salt+answer)

function buttOnClick(e)
{
	if (locked) return false;
	var t=$("#result");
	t.val(t.val()+"X");
	result+=e.target.text;
	if (t.val().length>=4)
	{
		if (md5(salt+result)===valid)
		{
			alert("Flag is: "+md5(result+valid));
		}
		else
		{
			locked=true;
			  $("#resultHolder").effect("shake", { times:tries }, tries*100,function(){
				t.val("");
				result="";
				tries++;
				locked=false;
				if (tries>20) alert("Maybe come back in a few minutes?");
			  });
		}
	}
}
$(function(){
	document.onclick = function(evt) {
    if (window.getSelection)
        window.getSelection().removeAllRanges();
    else if (document.selection)
        document.selection.empty();
	}

	$(".button").bind("click",buttOnClick);
});

</script>
</body>
</html>