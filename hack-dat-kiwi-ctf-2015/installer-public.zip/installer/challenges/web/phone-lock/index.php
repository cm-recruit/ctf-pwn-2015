<?php
date_default_timezone_set('America/New_York');
function salt($min)
{
	return md5("this is a long constant string which you should not be able to guess".$min);
}
function answer($min)
{
	return sprintf("%4d",(($min+1)*1379)%10000);
}
/** 
 * returns the number of minutes since the challenge was solved.
 * a good indicator of cheating if larger than a few minutes.
 */
function verify($hash)
{
	for ($i=0;$i<60*24;++$i)
	{
		$t=sprintf("%2d",$i);
		if (md5(salt($t).answer($t).answer($t))==$hash)
			return floor((time()-strtotime(floor($i/60).":".($i%60)))/60) ;
	}
	return false;
}
if (isset($_GET['verify']))
	die(verify($_GET['verify']));
$min=date('i')+date("H")*60;
$answer=answer($min);
$salt=salt($min);
?>
<html>
<head>
<script src="md5.js"></script>
<script src="jquery-1.11.1.min.js"></script>
<script src="jquery-ui.min.js"></script>
<title>Phone Lock</title>


</head>
<body>
<p>I forgot my phone password, can you help me unlock it? (Don't judge, happens to us all)</p>
<style>
#pad {
	width:350px;
	background-color:#222;
	padding:20px;
	height:350px;
	margin:auto;
	border: 1px solid gray;
		text-align: center;

}
#pad .button {
	width:30px;
	height:30px;
	overflow:hidden;
	text-align: center;
	border-radius: 50%;
	border:1px solid orange;
	color:white;
	margin:10px 20px 10px 20px;
	display:inline-block;
	padding:15px;
	cursor:pointer;
	font-size:24px;
}
#pad .button:HOVER {
}
#pad .button:ACTIVE {
	background-color:orange;
}
#resultHolder {
	margin:20px auto;
	border:3px inset gray;
	width:200px;
	text-align: center;
	overflow:hidden;
}
#result {
	border:none;
	font-size:60px;
	text-align: center;
	width:200px;
}
</style>

<div id='pad'>
	<a class='button'>1</a>
	<a class='button'>2</a>
	<a class='button'>3</a>
	<a class='button'>4</a>
	<a class='button'>5</a>
	<a class='button'>6</a>
	<a class='button'>7</a>
	<a class='button'>8</a>
	<a class='button'>9</a>
	<a class='button'>0</a>
</div>
<div id='resultHolder'>
<input  id='result' readonly='readonly'  value=''></input>
</div>
<script>
result="";
tries=0;
locked=false;
salt="<?php echo $salt;?>";
valid="<?php echo md5($salt.$answer);?>";
//md5(salt+answer)<?php //echo $answer;?>


function buttonClick(e)
{
	if (locked) return false;
	var t=$("#result");
	t.val(t.val()+"X");
	result+=e.target.text;
	if (t.val().length>=4)
	{
		if (md5(salt+result)==valid)
		{
			alert("Flag is: "+md5(salt+result+result));
		}
		else
		{
			locked=true;
			  $("#resultHolder").effect("shake", { times:tries }, tries*100,function(){
				t.val("");
				result="";
				tries++;
				locked=false;
			  });
		}
	}
}
$(function(){
	document.onclick = function(evt) {
    if (window.getSelection)
        window.getSelection().removeAllRanges();
    else if (document.selection)
        document.selection.empty();
	}

	$("#pad .button").bind("click",buttonClick);
});

</script>
</body>
</html>