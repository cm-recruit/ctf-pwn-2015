<?php
$question=$answers=array();
$question[]="Which choice is correct? That's the key.";
$answers[]=array("first and second","not first and forth","second and third","not first and not second");
$question[]="3X^2 -2X+7=12";
$answers[]=array("-1","7","9","-14");
$question[]="X-1=floor(sqrt(979))";
$answers[]=array("32","31","30","33");
$question[]="X=floor(sqrt(100+X))";
$answers[]=array("9","1","10","11");
$question[]="X=sin(15)//cos(15)";
$answers[]=array("tan(30)","tan(10)","tan(15)","sin(20)");
$question[]="X=sin(15)*sin(15) +cos(15)*cos(15)";
$answers[]=array("tan(15)","cos(15)","sin(15)","1");
$question[]="X=min(sqrt(1000),sqrt(sqrt(1000*1000)))";
$answers[]=array("sqrt(1000)","sqrt(sqrt(1000*1000))","sqrt(1000*1000)","33");
