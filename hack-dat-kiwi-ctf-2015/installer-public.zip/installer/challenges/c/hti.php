<h2>HTI (Experimental)</h2>
<p>You know what? I hate those companies that create cheap, insecure, crappy software, and then pay large sums of cash to buy
	security software like WAFs to protect that crap. Why don't you spend the money initially to fix the code?</p>

<p>The security software employed by this company has 3 modes of operation, some modes are slower and more secure, and some are faster and less secure.
Hack them to show this is not how you protect code.
</p>

<a  class='crypto start' href='<?=$c_url?>experimental/hti/'>Start</a>