<h2>Simple Stegano (Steganography)</h2>
<p>Just a basic stegano software. Find the message hidden in the original image, and you're good to go. You can hide any message you want in the image too!</p>

<a  class='crypto start' href='<?=$c_url?>crypto_stegano/simple_stegano/'>Start</a>