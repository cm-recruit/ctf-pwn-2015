<h2>Vigenere 2 (Crypto)</h2>
<p>So you got crypto skills, right? Try it again on Known Plaintext Mode:</p>

<a  class='crypto start' href='<?=$c_url?>crypto_stegano/vigenere/vigenere.php?mode=2'>Start</a>