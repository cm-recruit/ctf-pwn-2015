<h2>Virtual Virtue (Reversing)</h2>
<p>This virtually needs but actually boggles your mind. Find the proper sequence of inputs and maximize your score to win!</p>

<a  class='re start' href='<?=$c_url?>reversing_exploiting/virtual_virtue/virtual-no-rtti'>Download</a>