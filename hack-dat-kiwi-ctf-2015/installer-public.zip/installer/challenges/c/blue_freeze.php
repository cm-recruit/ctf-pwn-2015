<h2>Blue Freeze (Exploiting)</h2>
<p>There's a service running that can freeze! Exploit it and find the flag. It runs on port 1337, just netcat it.</p>

<p>The service runs under jailed environment with access to only sh, ls and cat binaries. The linked libraries are standards of this system.</p>
<a  class='crypto start' href='<?=$c_url?>reversing_exploiting/bluefreeze/handout'>Download</a>

