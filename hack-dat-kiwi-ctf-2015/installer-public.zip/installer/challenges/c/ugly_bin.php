<h2>Ugly Bin (Reversing)</h2>
<p>Ukh! That's one ugly binary. Why do people code like that? I guess if you give it the proper password, it generates the flag.</p>

<a  class='re start' href='<?=$c_url?>reversing_exploiting/ugly-bin/ugly-bin'>Download</a>