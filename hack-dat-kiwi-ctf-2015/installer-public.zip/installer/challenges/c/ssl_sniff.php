<h2>SSL Sniff 1 (Forensics)</h2>
<p>We received a network capture file of an HTTPS request that was MITMd. Try to find the culprit.</p>

<a  class='forensics start' href='<?=$c_url?>forensics/ssl_sniff/dump.pcap'>Download</a>