<h2>Vigenere 1 (Crypto)</h2>
<p>Vigenere is a classic cryptographic cipher. It is very simple, yet not that easy to break. Unless you break Vigenere on your own, 
	you can't call yourself a cryptanalyst. Start with the simplest mode, Chosen Plaintext Attack:</p>

<a  class='crypto start' href='<?=$c_url?>crypto_stegano/vigenere/vigenere.php?mode=1'>Start</a>