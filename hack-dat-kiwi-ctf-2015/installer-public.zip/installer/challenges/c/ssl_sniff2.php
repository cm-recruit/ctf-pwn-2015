<h2>SSL Sniff 2 (Forensics)</h2>
<p>We received a network capture file of an HTTPS request that was MITMd. This time we know that the actual request had useful information, and thanks to
you we now have the <a href='<?=$c_url?>forensics/ssl_sniff2/server.key.insecure'>culprit's private key</a>. Find the useful information.</p>

<a  class='forensics start' href='<?=$c_url?>forensics/ssl_sniff2/client.pcap'>Download</a>