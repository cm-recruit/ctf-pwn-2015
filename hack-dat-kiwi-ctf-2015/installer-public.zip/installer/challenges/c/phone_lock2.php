<h2>Phone Lock 2 (Web)</h2>
<p>Remember my friend you fixed her phone? She told everybody about it. One of her friends has a crappy phone, and he's pretty sure he knows what the password
is, but the password doesn't work. Since you're a hacker and all, he wants you to figure out whats wrong!</p>

<a  class='web start' href='<?=$c_url?>web/phone-lock2/'>Start</a>