<h2>Leet Maze (Forensics)</h2>
<p>We found a malware that communicates with track.dat.kiwi, however, there's nothing on track.dat.kiwi! It appears
	that they have established a complicated network of DNS records to point to the C&amp;C server.</p>

<p>It's basically like CNAME, the software follows track.dat.kiwi to find out the target server. However, there are
	some caveats.</p>

<p><strong>Hint:</strong> To send a DNS request to a particular server for a particular record type, you can use the tool 
	<strong>dig</strong> that comes with BIND like this:</p>
<pre style='background-color:black;padding:5px; border:3px double white;color:white;margin:5px;'>
dig @server track.dat.kiwi TXT
</pre>


