<h2>Gaychal (Reversing)</h2>
<p>I found some suspicious PHP code on my website. The code was attached to my theme's footer file.
It's either the DRM of the theme, or a virus; however it's encoded and I can't figure it out. Do that for me please :)</p>

<a  class='re start' href='<?=$c_url?>reversing_exploiting/gaychal/gaychal.txt'>Download</a>