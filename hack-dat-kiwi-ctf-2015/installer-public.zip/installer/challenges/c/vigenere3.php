<h2>Vigenere 3 (Crypto)</h2>
<p>Well those two were child's play. I just wanted to see if you know any crypto at all or not. The real deal starts here, Ciphertext-only Attack:</p>

<a  class='crypto start' href='<?=$c_url?>crypto_stegano/vigenere/vigenere.php?mode=3'>Start</a>