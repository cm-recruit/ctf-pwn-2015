<h2>Kiwi Forum 2 (Web)</h2>
<p>That was a nasty bug!  But not anymore. Try it this time.</p>

<a  class='web start' href='<?=$c_url?>web/kiwi-forum2/'>Start</a>