<h2>Math Quiz (Web)</h2>
<p>So I got this douchy classmate that thinks he's super cool. He created a math quiz software for our class in 10 minutes, and claims its super secure with
protections and everything. We all hate him, and if you hack his code, we're gonna love you! By the way, he told a friend of mine that he keeps his secrets 
among the quiz questions, but those questions are never used in the software.</p>


<a  class='web start' href='<?=$c_url?>web/math-quiz/'>Start</a>