<h2>Vigenere 4 (Crypto)</h2>
<p>I'm starting to like you! Break this one and you earn the right to brag!</p>

<a  class='crypto start' href='<?=$c_url?>crypto_stegano/vigenere/vigenere.php?mode=4'>Start</a>