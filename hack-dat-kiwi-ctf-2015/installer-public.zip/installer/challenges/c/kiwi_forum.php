<h2>Kiwi Forum (Web)</h2>
<p>A full fledged Kiwi software! And a forum at that. It's also <a href='<?=$c_url?>web/kiwi-source.zip'>open source</a>.</p>
<p>The admins on this forum are so proud of their product, they have put their flag keys on their avatar photos!</p>


<a  class='web start' href='<?=$c_url?>web/kiwi-forum/'>Start</a>