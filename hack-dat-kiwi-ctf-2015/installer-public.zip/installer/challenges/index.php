<html>
<head>
	<title>Hack Dat Kiwi 2015</title>
</head>
<body>
<style>
#legend a {
	min-height:24px;
	min-width:24px;
	display:inline-block;
	vertical-align: middle;
	margin-left:20px;
}
#legend {
	border:1px solid gray;
	padding:3px;
	margin:5px;
	margin-top:0;
	width:auto;
	padding-right:20px;
	float:right;
}
a.start {
	display:inline-block;
	padding:10px 20px 10px 20px ;
	border:2px inset;
	border-radius: 15px;
	margin:10px;
	text-decoration: none;
	font-size:24px;
}
a.start:after {
	content:' The Challenge';
}
a.start:hover {
	border-color:gray;
}
.re {
	background-color:darkred;
	color:white;
}
.web {
	background-color:darkblue;
	color:white;
}
.forensics {
	background-color:yellow;
}
.crypto {
	background-color:darkgreen;
	color:white;
}
.experimental {
	background-color:#444;
	color:white;
}
</style>
<div id='legend'>
	<a class='web'></a> Web
	<a class='re'></a> Reverse Engineering / Exploitation
	<a class='forensics'></a> Forensics
	<a class='crypto'></a> Cryptography / Steganography
	<a class='experimental'></a> Experimental / Academic
</div>
<?php 

if (isset($_POST['flag']))
{

	require_once __DIR__."/flags.php";
	if ($r=match(md5($_POST['flag'])))
		echo "Valid flag for challenge number {$r}!<br/>";
	else
		echo "Invalid flag.<br/>";
}
?>
<form method='post'>
	<label>Submit Flag:</label> <input type='text' name='flag' /><input type='submit' />
</form>
<?php
$c_url="./";
if (isset($_GET['page']))
{
        $page=realpath(__DIR__."/c/".$_GET['page'].".php");
        if (dirname($page)===__DIR__."/c" and substr($page,-3)=="php")
                include $page;
}
else
{
?>
<style>
#challenges tr {
	text-align:center;
}
#challenges td {
	vertical-align: middle;
	width:20%;
}

#challenges a {
	color:inherit;
	text-decoration: none;
	display:inline-block;
	line-height: 100px;

}

</style>

<table id='challenges' border='1' cellpadding='0' cellspacing='0' width='100%'>
	<tr>
		<td class='web'>
			<a href='?page=phone_lock'>
			Phone-Lock (50)
			<a/>
		</td>
		<td class='forensics'>
			<a href='?page=ssl_sniff'>
			SSL Sniff (50)
			</a>
		</td>
		<td class='re'>
			<a href='?page=gaychal'>
			Gaychal (80)
			</a>
		</td>
		<td class='web'>
			<a href='?page=phone_lock2'>
			Phone-Lock 2 (100)
			</a>
		</td>
		<td  class='crypto'>
			<a href='?page=vigenere'>
			Vigenere 1 (50)
			</a>
		</td>
	</tr>
	<tr>
		<td class='crypto'>
			<a href='?page=vigenere2'>
			Vigenere 2 (80)
			</a>
		</td>
		<td class='web'>
			<a href='?page=kiwi_forum'>
			Kiwi Forum 1 (120)
			</a>
		</td>
		<td class='web'>
			<a href='?page=math_quiz'>
			Math Quiz (150)
			</a>
		</td>
		<td class='crypto'>
			<a href='?page=vigenere3'>
			Vigenere 3 (120)
			</a>
		</td>
		<td class='re'>
			<a href='?page=ugly_bin'>
			Ugly Bin (180)
			</a>
		</td>
	</tr>
	<tr>
		<td class='forensics'>
			<a href='?page=ssl_sniff2'>
			SSL Sniff 2 (120)
			</a>
		</td>
		<td class='crypto'>
			<a href='?page=vigenere4'>
			Vigenere 4 (220)
			</a>
		</td>
		<td class='crypto'>
			<a href='?page=simple_stegano'>
			Simple Stegano (250)
			</a>
		</td>
		<td class='re'>
			<a href='?page=virtual_virtue'>
			Virtual Virtue (150)
			</a>
		</td>
		<td class='experimental'>
			<a href='?page=nti'>
			NTI (150)
			</a>
		</td>
	</tr>
	<tr>
		<td class='re'>
			<a href='?page=blue_freeze'>
			Blue Freeze (250)
			</a>
		</td>
		<td class='forensics'>
			<a href='?page=leet_maze'>
			Leet Maze (250)
			</a>
		</td>
		<td class='web'>
			<a href='?page=kiwi_forum2'>
			Kiwi Forum 2 (250)
			</a>
		</td>
		<td class='web'>
			<a href='?page=captcha_password'>
			Captcha Password (300)
			</a>
		</td>
		<td class='experimental'>
			<a href='?page=pti'>
			PTI (200)
			</a>
		</td>
	</tr>
	<tr>
		<td colspan='2'></td>
		<td class='experimental'>
			<a href='?page=hti'>
			HTI (250)
			</a>
		</td>
		<td colspan='2'></td>
	</tr>
</table>
<?php }
?>
</body>
</html>