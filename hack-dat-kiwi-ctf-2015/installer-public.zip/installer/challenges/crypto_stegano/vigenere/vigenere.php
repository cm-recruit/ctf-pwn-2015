<?php
function classic_string($string,$space=false)
{
   $string=preg_replace('/[^\x20-\x7E]/','', $string);
  $string= preg_replace("/[^A-Za-z]/", ' ', strtoupper($string)); //remove non-alphanumeric
  if (!$space) $string= str_replace(" ", "", $string);
  return $string;
}
function autokey_encrypt($message,$key)
{
  $message=classic_string($message);
  $key=classic_string($key);
  $keyLength = strlen($key);

  $index=0;
  $output="";
  for ($i=0;$i<strlen($message);++$i)
  {  
      $val=ord($message[$i])-ord('A');
      $keyval=ord($key[$i%$keyLength])-ord('A');
      $char=($val+$keyval)%26 ;
      $key[$i%$keyLength]=chr(($keyval+$char)%26 +ord('A'));

      $output.=chr($char+ord('A'));
  }
  return implode(" ",str_split($output,5));
}
function vigenere_encrypt($message,$key)
{
  $message=classic_string($message);
  $key=classic_string($key);
  $keyLength = strlen($key);

  $index=0;
  $output="";
  for ($i=0;$i<strlen($message);++$i)
  {  
      $val=ord($message[$i])-ord('A');
      $keyval=ord($key[$i%$keyLength])-ord('A');
      $output.=chr(($val+$keyval)%26 + ord('A'));
  }
  return implode(" ",str_split($output,5));
}
function vigenere_decrypt($message,$key)
{
  $message=classic_string($message);
  $key=classic_string($key);
  $keyLength = strlen($key);

  $index=0;
  $output="";
  for ($i=0;$i<strlen($message);++$i)
  {  
      $val=ord($message[$i])-ord('A');
      $keyval=ord($key[$i%$keyLength])-ord('A');
      $output.=chr(($val-$keyval+26)%26 + ord('A'));
  }
  return $output;
}

if (isset($_GET['mode']))
  $mode=$_GET['mode']*1;
else 
  $mode=1;
?>
<html>
<head>
  <style>
  body {
    width:600px;
    margin:auto;
  }
  #plaintext,#ciphertext {
    border:3px double gray;
    background-color:AAA;
    padding:10px;
    font-family: courier;
    word-wrap: break-word;
    word-break: break-word;
    margin:10px auto;
  }
  textarea {
    width:100%;
  }
  </style>
</head>
<body>
  <h2>Introduction</h2>
<p>
   Contrary to popular belief, in Cryptography, breaking a cipher is not the process of finding plaintext relating to a ciphertext.
   Breaking a cipher (Cryptanalysis) is the process of finding the Key used to encrypt a data. Once a Key is found, many instances of data
   can be decrypted. That's why in modern ciphers, even if you know the plaintext (or even select it), you should not be able to find the Key.
 </p>
<?php
if ($mode==1)
{
  $title="Chosen Plaintext Attack";
  $key="KIWIKI";
  if (isset($_POST['msg'])) 
  {
    $data=classic_string($_POST['msg'],1);
    $encrypted=vigenere_encrypt($data,$key);
    echo "<h2>{$title}</h2>\n";
    echo "<fieldset id='plaintext'><legend>Plaintext</legend>{$data}</fieldset>\n<fieldset id='ciphertext'><legend>Ciphertext</legend>{$encrypted}</fieldset>";
  }
  ?>
  <form method='post'>
    Message to encrypt:
    <textarea cols='80' rows='10' name='msg' ></textarea>
    <br/><input type='submit' />
  </form>
  <?php
}
elseif ($mode==2)
{
  $key="XEROX";
  $title="Known Plaintext Attack";
    $data=classic_string(file_get_contents("sample.txt"),1);
    $encrypted=vigenere_encrypt($data,$key);
    echo "<h2>{$title}</h2>\n";
    echo "<fieldset id='plaintext'><legend>Plaintext</legend>{$data}</fieldset>\n<fieldset id='ciphertext'><legend>Ciphertext</legend>{$encrypted}</fieldset>";
}
elseif ($mode==3)
{
  $key="DAMNLONGPASSWORD";
  $title="Ciphertext-only Attack";
    $data=classic_string(file_get_contents("sample2.txt"),1);
    $encrypted=vigenere_encrypt($data,$key);
    echo "<h2>{$title}</h2>\n";
    echo "<fieldset id='ciphertext'><legend>Ciphertext</legend>{$encrypted}</fieldset>";
}
elseif ($mode==4)
{
  $key="THISCIPHERISCALLEDAUTOKEY";
  $title="(Advanced) Ciphertext-only Attack";
    $data=classic_string(file_get_contents("sample3.txt"),1);
    $encrypted=autokey_encrypt($data,$key);
    echo "<h2>{$title}</h2>\n";
    echo "<fieldset id='ciphertext'><legend>Ciphertext</legend>{$encrypted}</fieldset>";

}
else
  echo "<br/><br/>:)<br/><br/>";

?>
</body>
