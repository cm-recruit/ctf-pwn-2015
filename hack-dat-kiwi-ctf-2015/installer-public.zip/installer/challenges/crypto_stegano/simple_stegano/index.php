<?php
$id="the-troll";
if (isset($_GET['msg']) and $_GET['msg']!="")
{
	$id=md5($_GET['msg']);
	if (!file_exists(__DIR__."/trolls/{$id}.png"))
	{
		// var_dump("./stegano.py ".escapeshellarg($_GET['msg'])." troll.png trolls/{$id}.png");
		shell_exec("python stegano.py ".escapeshellarg($_GET['msg'])." troll.png trolls/{$id}.png");
		file_put_contents(__DIR__."/trolls/log.txt",$_GET['msg'].PHP_EOL.PHP_EOL,FILE_APPEND);
	}
}
?>
<div style='text-align:center;width:500px;margin:auto;'>
<img src='trolls/<?=$id;?>.png' />
<form>
Reply: <input type='text' name='msg' /></input type='submit' />
</form>
</div>