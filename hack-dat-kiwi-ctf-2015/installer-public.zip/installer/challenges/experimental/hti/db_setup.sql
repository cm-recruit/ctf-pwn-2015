
CREATE TABLE IF NOT EXISTS `secrets` (
  `ID` int(11) NOT NULL,
  `flag` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `secrets` (`ID`, `flag`, `password`) VALUES
(1, 'jrigvwpq0kv92180u031n', '0rwj38paijmf0j0p2jf9wrah0ov9h0p');

CREATE TABLE IF NOT EXISTS `tickets` (
  `ID` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `sessionid` varchar(128) NOT NULL,
  `title` varchar(32) NOT NULL,
  `message` text NOT NULL
) AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

ALTER TABLE `secrets`
  ADD PRIMARY KEY (`ID`);

ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `timestamp` (`timestamp`),
  ADD KEY `sessionid` (`sessionid`);

