<?php
define("ti_mode",2); //1=PTI, 2=NTI, 3=HTI (PTI+NTI)
