<?php
if (posix_getuid()!="0")
	die("run as sudo\n");
function shell($cmd)
{
	echo str_repeat("-",80),PHP_EOL;
	echo '$ '.$cmd,PHP_EOL;
	flush();
	$r=shell_exec($cmd." 2>&1");
	echo $r;

}
function live_shell($cmd,$hold=true)
{
	echo str_repeat("-",80),PHP_EOL;
	echo '$ ',$cmd,PHP_EOL;
	$descriptorspec = array(
   		0 => array("pipe", "r"),   
   		1 => array("pipe", "w"),   
   		2 => array("pipe", "w")    
   	);
	flush();
	$process = proc_open($cmd, $descriptorspec, $pipes, realpath('./'), array());
	if (is_resource($process)) 
		while ($hold and ($s = fgetc($pipes[1]))!==false) 
		{
			print $s;
			flush();
		}
	proc_close($process);

}
/**
 * Configurations
 */
$webdir="/var/www/html/";
$mysql_pass="123456aB_24fjiwpfv";
$mysql_kiwi_forum_pass="3EjFhMEQAMmqJORo";
$mysql_experimental_pass=["yKzuCTq9dcl30hvy",'VoMui85KpfkpCs7P','61vkHg0mNDf8b95f'];
$experimental_flags=["Fpv41tyP9pAcsTODxJT9whBpHe7k",'IUKtGJFvGuhtXCasgy8FR8kGvNJG','RJvmnUmBjhkn8G0Zd0qYHObdKhMB'];

$user="www-data";
$admin_user="kiwi";
$admin_pass="NhX0U8FvDmw53";
 

#php
shell('apt-get install -y php5-cgi php5-curl php5-gd php5-imagick php5-mysql php5-memcache php5-sqlite php5-mcrypt');

#bind 
shell('apt-get install -y bind9 ssh');
shell("echo 'zone \"dat.kiwi\" {\n             type master;\n             file \"/etc/bind/db.dat.kiwi\";\n        };\n' >>/etc/bind/named.conf.local");
$ip=trim(shell_exec("echo `ifconfig eth0 2>/dev/null|awk '/inet addr:/ {print $2}'|sed 's/addr://'`"));
$dns=file_get_contents(__DIR__."/dns.txt");
$dns=str_replace("==IP==", $ip, $dns);
// shell('cp dns.txt /etc/bind/db.dat.kiwi');
file_put_contents("/etc/bind/db.dat.kiwi",$dns);
shell('sed -i \'/auth-nx/,/listen-on/ s/li/allow-transfer{"none";};\n\tli/\' /etc/bind/named.conf.options'); #disable zone transfer
shell('service bind9 restart');


#apache
shell('apt-get install -y apache2 libapache2-mod-php5');
shell('apt-get install -y python-dev libjpeg-dev libpng3 libjpeg8-dev libfreetype6-dev zlib1g-dev');
shell('apt-get install -y python-pil');

#live_shell('apt-get install -y python-setuptools python-dev python-pip');
#live_shell('easy_install pil');
#live_shell('pip install Pillow');

shell('a2enmod php5');
shell('a2enmod ssl');
shell('a2enmod rewrite');
shell('a2ensite 000-default');

shell("sed -i '/<Directory \/var\/www\/>/,/<\/Directory>/ s/AllowOverride None/AllowOverride All/' /etc/apache2/apache2.conf");
shell("service apache2 restart");

#mysql
shell("apt-get install -y --force-yes debconf-utils");
$s="debconf-set-selections <<< 'mysql-server mysql-server/root_password password {$mysql_pass}';
debconf-set-selections <<< 'mysql-server mysql-server/root_password_again password {$mysql_pass}';
apt-get install -y mysql-server mysql-client;";
file_put_contents("mysql.sh",$s);
shell("chmod +x mysql.sh");
shell("bash mysql.sh");
shell("rm mysql.sh");

#user setup
shell("useradd {$admin_user}");
shell("adduser kiwi sudo");
shell("echo '{$admin_user}:{$admin_pass}' | chpasswd");

#webmin
#live_shell("wget 'http://prdownloads.sourceforge.net/webadmin/webmin_1.770_all.deb' -O webmin.deb");
#live_shell("apt-get install -y perl libnet-ssleay-perl openssl libauthen-pam-perl libpam-runtime libio-pty-perl apt-show-versions");
#live_shell("dpkg -i webmin.deb");

#challenges
shell("cp -r challenges/* {$webdir}");
shell("rm {$webdir}/index.html");

#challenge permissions
shell("chown www-data.www-data -R {$webdir}");
shell("find {$webdir} -type d -exec chmod 500 {} +");
shell("find {$webdir} -type f -exec chmod 400 {} +");

#stegano challenge
shell("chmod 700 {$webdir}/crypto_stegano/simple_stegano/trolls/");

#web challenges
shell("chmod 700 {$webdir}/web/kiwi-forum/db/");
shell("chmod 700 {$webdir}/web/kiwi-forum2/db/");


$s="
CREATE USER 'kiwi-forum'@'localhost' IDENTIFIED BY '{$mysql_kiwi_forum_pass}';
GRANT USAGE ON *.* TO 'kiwi-forum'@'localhost' IDENTIFIED BY '{$mysql_kiwi_forum_pass}' REQUIRE NONE WITH MAX_QUERIES_PER_HOUR 0 MAX_CONNECTIONS_PER_HOUR 0 MAX_UPDATES_PER_HOUR 0 MAX_USER_CONNECTIONS 0;
GRANT ALL PRIVILEGES ON `kiwi-forum`.* TO 'kiwi-forum'@'localhost';
";
for ($i=0;$i<3;++$i)
{
	$s.="
CREATE DATABASE `secrets{$i}`;
USE `secrets{$i}`;
CREATE TABLE IF NOT EXISTS `secrets` (
  `ID` int(11) NOT NULL,
  `flag` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `secrets` (`ID`, `flag`, `password`) VALUES
(1, '{$experimental_flags[$i]}', '0rwj38pa9{$experimental_flags[$i]}ah0ov9h0p');

CREATE TABLE IF NOT EXISTS `tickets` (
  `ID` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `sessionid` varchar(128) NOT NULL,
  `title` varchar(32) NOT NULL,
  `message` text NOT NULL
) AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

ALTER TABLE `secrets`
  ADD PRIMARY KEY (`ID`);

ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `timestamp` (`timestamp`),
  ADD KEY `sessionid` (`sessionid`);

	CREATE USER 'secrets{$i}'@'localhost' IDENTIFIED BY '{$mysql_experimental_pass[$i]}';
	GRANT USAGE ON *.* TO 'secrets{$i}'@'localhost' IDENTIFIED BY '{$mysql_experimental_pass[$i]}' REQUIRE NONE WITH MAX_QUERIES_PER_HOUR 0 MAX_CONNECTIONS_PER_HOUR 0 MAX_UPDATES_PER_HOUR 0 MAX_USER_CONNECTIONS 0;
	GRANT ALL PRIVILEGES ON `secrets{$i}`.* TO 'secrets{$i}'@'localhost';

ALTER TABLE `tickets`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
	";
}
file_put_contents("database.sql",$s);
shell("mysql -u root -p{$mysql_pass} <database.sql");

#kiwi forum has mysql setup (in load.php)
#experimental has mysql setup (config.php)


#exploitation challenge setup
shell("mkdir -p /home/kiwi");
shell("mv {$webdir}/reversing_exploiting/bluefreeze/chroot /home/kiwi/");
shell("chown kiwi.kiwi -R /home/kiwi");
shell("chmod +x /home/kiwi/chroot/server");
shell("chmod +x /home/kiwi/chroot/bin/*");
shell("chmod 755 -R /home/kiwi/chroot/lib*");
live_shell("chroot /home/kiwi/chroot /server &",false);

shell("cd ..; rm -rf installer");

echo "All done.",PHP_EOL;
exit(0);
